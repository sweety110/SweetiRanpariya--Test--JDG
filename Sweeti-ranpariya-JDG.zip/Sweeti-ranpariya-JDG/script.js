
// menu
let nav;
let navNutton;
let menu;


let counter = 0;

window.onload = (event) => {
  
  nav = document.getElementById("nav-menu-container");
  navButton = document.getElementById("nav-button");
  menu = document.getElementById("nav-menu");
  
  navButton.addEventListener("click", showHideMenu);
  
};

function showHideMenu(){
  
  switch(counter){
      
    case 0:
      
        menu.classList.remove("hide-nav-menu");
        menu.classList.add("show-nav-menu");
      
        counter++;
      
        break;
      
    case 1:
      
        menu.classList.remove("show-nav-menu");
        menu.classList.add("hide-nav-menu");
      
        counter = 0;
      
        break;
      
  }
  
}


// navbar
$(document).ready(function() {
    // Swiper: Slider
        new Swiper('.knowmore-slider', {
            loop: true,
            nextButton: '.swiper-button-next',
            prevButton: '.swiper-button-prev',
            slidesPerView: 1,
            loop:false,
            allowSlidePrev:false,
            paginationClickable: true,
        });
    });
    

// tab
$(document).ready(function(){
	$(".Tab2").hide();
	$(".Tab3").hide();		
	$(".one").eq(0).addClass("active");
	$(".one").click(function(){
		$(".one").removeClass("active");
	
		$(".Tab1").hide();
	$(".Tab2").hide();
	$(".Tab3").hide();
	var aval=	$(this)[0].innerText;	
	$("."+aval).show();
	$(this).addClass("active");	
});
});

//testimonial-slider
const gallerySlider = new Swiper(".testimonial-slider", {
  loop: true,
  slidesPerView: 2,
  nextButton: '.swiper-button-next',
  prevButton: '.swiper-button-prev',
  centeredSlides: true,
  speed: 300,
  grabCursor: true,
  spaceBetween: 50,
  parallax: true,
  breakpoints: {
    1920: {
        slidesPerView: 2,
        spaceBetween: 50,
    },
    1400: {
        slidesPerView: 2,
        spaceBetween: 20,
    },
    767: {
        slidesPerView: 1,
        spaceBetween: 10,
    }
}
});

